

<?php $__env->startSection('title', 'Gestión de Categorias'); ?>

<?php $__env->startSection('styles'); ?>
  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
  <div class="page-header">
    <h3 class="page-title">
      Categorias
    </h3>
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="/">Panel Administrativo</a></li>
        <li class="breadcrumb-item active" aria-current="page">Categorias</li>
      </ol>
    </nav>
  </div>
  <div class="card">
    <div class="card-body">
      <div class="d-flex justify-content-between">
          <h4 class="card-title">Categorias</h4>
          <div class="nav-link">
            
          <i class="fas fa-ellipsis-v" data-toggle="dropdown"></i>
          <div class="dropdown-menu navbar-dropdown" aria-labelledby="languageDropdown">
            <a class="dropdown-item font-weight-medium" href="<?php echo e(route('categories.create')); ?>">
              Agregar
            </a>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-12">
          <div class="table-responsive">
            <table id="order-listing" class="table">
              <thead>
                <tr>
                    <th>Id</th>
                    <th>Nombre</th>
                    <th>Descripcion</th>
                    <th>Acciones</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($category->id); ?></td>
                    <td><?php echo e($category->name); ?></td>
                    <td><?php echo e($category->description); ?></td>
                    <td>
                      <?php echo Form::open(['route' => ['categories.destroy', $category], 'method' => 'DELETE']); ?>

                      <a href="<?php echo e(route('categories.edit', $category)); ?>" class="jsgrid-button jsgrid-edit-button" title="Editar categoria <?php echo e($category->name); ?>"><i class="fas fa-edit"></i></a>
                      
                      <button type="submit" class="jsgrid-button jsgrid-delete-button text-danger" title="Eliminar categoria <?php echo e($category->name); ?>" style="border: none; background: none; padding: 0;"><i class="far fa-trash-alt"></i></button>
                      <?php echo Form::close(); ?>

                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php $__env->startSection('scripts'); ?>
  <?php echo e(Html::script("js/data-table.js")); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\puntodeventa\resources\views/admin/category/index.blade.php ENDPATH**/ ?>