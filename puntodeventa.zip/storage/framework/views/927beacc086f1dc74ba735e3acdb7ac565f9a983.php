

<?php $__env->startSection('title', 'Registrar Compra'); ?>

<?php $__env->startSection('styles'); ?>
  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
  <div class="page-header">
    <h3 class="page-title">
      Registro de Compras
    </h3>
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="/">Panel Administrativo</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('purchases.index')); ?>">Compras</a></li>
        <li class="breadcrumb-item active" aria-current="page">Registrar Compra</li>
      </ol>
    </nav>
  </div>
    <div class="card">
      <div class="card-body">
        <div class="d-flex justify-content-between">
            <h4 class="card-title">Registro de Compras</h4>
        </div>
        <?php echo Form::open(['route' => 'purchases.store', 'method' => 'POST']); ?>

          <?php echo $__env->make('admin.purchase._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <button type="button" class="btn btn-success float-right" id="agregar">Añadir Producto</button>
        </div>
        <div class="card-footer">
          <button type="submit" class="btn btn-primary">Guardar</button>
          <a href="<?php echo e(route('purchases.index')); ?>" class="btn btn-light">Cancelar</a>    
      </div>
      <?php echo Form::close(); ?>

    </div>
</div>

<?php $__env->startSection('scripts'); ?>
  <?php echo e(Html::script("js/alerts.js")); ?>

  <?php echo e(Html::script("js/avgrund.js")); ?>

  <?php echo e(Html::script("js/scripts/agregarProducto.js")); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\puntodeventa\resources\views/admin/purchase/create.blade.php ENDPATH**/ ?>