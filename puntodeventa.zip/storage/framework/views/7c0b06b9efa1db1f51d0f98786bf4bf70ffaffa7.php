

<?php $__env->startSection('title', 'Detalles de la compra '. $purchase->id); ?>

<?php $__env->startSection('styles'); ?>
  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
    <div class="page-header">
      <h3 class="page-title">
        Detalle de la compra
      </h3>
      <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="#">Panel Administrativo</a></li>
          <li class="breadcrumb-item"><a href="<?php echo e(route('purchases.index')); ?>">Compras</a></li>
          <li class="breadcrumb-item active" aria-current="page">Detalle de la compra</li>
        </ol>
      </nav>
    </div>
    <div class="row">
      <div class="col-12">
        <div class="card">
          <div class="card-body">
            <div class="form-group row">
              <div class="col-md-4 text-center">
                  <label class="form-control-label" for="nombre"><strong>Proveedor</strong></label>
                  <p><?php echo e($purchase->provider->name); ?></p>
              </div>
              <div class="col-md-4 text-center">
                  <label class="form-control-label" for="num_compra"><strong>Número Compra</strong></label>
                  <p><?php echo e($purchase->id); ?></p>
              </div>
              <div class="col-md-4 text-center">
                  <label class="form-control-label" for="num_compra"><strong>Comprador</strong></label>
                  <p><?php echo e($purchase->user->name); ?></p>
              </div>
            </div>
            <div class="table-responsive col-md-12">
              <table class="table">
                <thead>
                  <tr>
                    <th>Producto</th>
                    <th>Precio</th>
                    <th>Cantidad</th>
                    <th>Subtotal</th>
                  </tr>
                </thead>
                <tfoot>
                  <tr>
                      <th colspan="3"><p class="float-right">SUBTOTAL:</p></th>
                      <th><p class="float-right">$<?php echo e(number_format($subtotal, 2, '.', ',')); ?></p></th>
                  </tr>
                  <tr>
                      <th colspan="3"><p class="float-right">TOTAL IMPUESTO (<?php echo e($purchase->tax); ?>%):</p></th>
                      <th><p class="float-right">$<?php echo e(number_format($subtotal * $purchase->tax/100, 2, '.', ',')); ?></p></th>
                  </tr>
                  <tr>
                      <th colspan="3"><p class="float-right">TOTAL:</p></th>
                      <th><p class="float-right">$<?php echo e(number_format($purchase->total, 2, '.', ',')); ?></p></th>
                  </tr>
  
              </tfoot>
                <tbody>
                  <?php $__currentLoopData = $purchaseDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchaseDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($purchaseDetail->product->name); ?></td>
                      <td>$<?php echo e($purchaseDetail->price); ?></td>
                      <td><?php echo e($purchaseDetail->quantity); ?></td>
                      <td>$<?php echo e(number_format($purchaseDetail->quantity *  $purchaseDetail->price, 2, '.', ',')); ?></td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
          <div class="card-footer">
            <a href="<?php echo e(route('purchases.index')); ?>" class="btn btn-primary float-right">Regresar</a>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->startSection('scripts'); ?>
  <?php echo e(Html::script("js/data-table.js")); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\puntodeventa\resources\views/admin/purchase/show.blade.php ENDPATH**/ ?>