

<?php $__env->startSection('title', 'Editar Producto ' . $product->name); ?>

<?php $__env->startSection('styles'); ?>
  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
  <div class="page-header">
    <h3 class="page-title">
      Editar Producto <?php echo e($product->name); ?>

    </h3>
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="/">Panel Administrativo</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('products.index')); ?>">Productos</a></li>
        <li class="breadcrumb-item active" aria-current="page">Editar Producto <?php echo e($product->name); ?></li>
      </ol>
    </nav>
  </div>
    <div class="card">
      <div class="card-body">
        <div class="d-flex justify-content-between">
            <h4 class="card-title">Editar Producto <?php echo e($product->name); ?></h4>
        </div>
        <?php echo Form::model($product, ['route' => ['products.update', $product], 'method' => 'PUT', 'files' => true]); ?>

        <div class="form-group">
          <label for="name">Nombre</label>
          <input type="text" name="name" id="name" placeholder="Ingresa el nombre" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('name', $product->name)); ?>" required>
          <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <small class="text-danger"><?php echo e($message); ?></small>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
            <label for="sell_price">Precio Venta</label>
            <input type="text" name="sell_price" id="sell_price" placeholder="0.00" class="form-control <?php $__errorArgs = ['sell_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('sell_price', $product->sell_price)); ?>" required>
            <?php $__errorArgs = ['sell_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
            <label for="category_id">Nombre</label>
            <select name="category_id" id="category_id" class="form-control">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($category->id == $product->category_id): ?>
                      <option value="<?php echo e($category->id); ?>" selected><?php echo e($category->name); ?></option>
                    <?php else: ?>
                      <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>    
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
            <label for="provider_id">Proveedor</label>
            <select name="provider_id" id="provider_id" class="form-control">
                <?php $__currentLoopData = $providers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($provider->id == $product->provider_id): ?>
                      <option value="<?php echo e($provider->id); ?>" selected><?php echo e($provider->name); ?></option>
                    <?php else: ?>
                      <option value=""><?php echo e($provider->name); ?></option>    
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['provider_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="card">
          <div class="card-body">
            <h4 class="card-title d-flex">Imagen de Producto
              <small class="ml-auto align-self-end">
                <a class="font-weight-light">Seleccionar archivo</a>
              </small>
            </h4>
            <input type="file" name="picture" id="picture" class="dropify" />
          </div>
        </div>
          <button type="submit" class="btn btn-primary">Actualizar</button>
          <a href="<?php echo e(route('products.index')); ?>" class="btn btn-light">Cancelar</a>
        <?php echo Form::close(); ?>

      </div>
    </div>
</div>

<?php $__env->startSection('scripts'); ?>
  <?php echo e(Html::script("js/dropify.js")); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\puntodeventa\resources\views/admin/product/edit.blade.php ENDPATH**/ ?>