

<?php $__env->startSection('title', 'Registrar Proveedor'); ?>

<?php $__env->startSection('styles'); ?>
  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
  <div class="page-header">
    <h3 class="page-title">
      Registro de Poveedores
    </h3>
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="/">Panel Administrativo</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('providers.index')); ?>">Poveedores</a></li>
        <li class="breadcrumb-item active" aria-current="page">Registrar Proveedor</li>
      </ol>
    </nav>
  </div>
    <div class="card">
      <div class="card-body">
        <div class="d-flex justify-content-between">
            <h4 class="card-title">Registro de Poveedores</h4>
        </div>
        <?php echo Form::open(['route' => 'providers.store', 'method' => 'POST']); ?>

          <?php echo $__env->make('admin.provider._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <button type="submit" class="btn btn-primary">Guardar</button>
          <a href="<?php echo e(route('providers.index')); ?>" class="btn btn-light">Cancelar</a>
        <?php echo Form::close(); ?>

      </div>
    </div>
</div>

<?php $__env->startSection('scripts'); ?>
  <?php echo e(Html::script("js/data-table.js")); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\puntodeventa\resources\views/admin/provider/create.blade.php ENDPATH**/ ?>