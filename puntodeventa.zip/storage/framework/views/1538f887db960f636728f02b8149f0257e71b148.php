

<?php $__env->startSection('title', 'Detalles de la venta '. $sale->id); ?>

<?php $__env->startSection('styles'); ?>
  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
    <div class="page-header">
      <h3 class="page-title">
        Detalle de la venta
      </h3>
      <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="#">Panel Administrativo</a></li>
          <li class="breadcrumb-item"><a href="<?php echo e(route('sales.index')); ?>">ventas</a></li>
          <li class="breadcrumb-item active" aria-current="page">Detalle de la venta</li>
        </ol>
      </nav>
    </div>
    <div class="row">
      <div class="col-12">
        <div class="card">
          <div class="card-body">
            <div class="form-group row">
              <div class="col-md-4 text-center">
                  <label class="form-control-label" for="num_venta"><strong>Número venta</strong></label>
                  <p><?php echo e($sale->id); ?></p>
              </div>
            </div>
            <div class="table-responsive col-md-12">
              <table class="table">
                <thead>
                  <tr>
                    <th>Producto</th>
                    <th>Precio Venta</th>
                    <th>Cantidad</th>
                    <th>Descuento (%)</th>
                    <th>Subtotal</th>
                  </tr>
                </thead>
                <tfoot>
                  <tr>
                      <th colspan="4"><p class="float-right">SUBTOTAL:</p></th>
                      <th><p class="float-right">$<?php echo e(number_format($subtotal, 2, '.', ',')); ?></p></th>
                  </tr>
                  <tr>
                      <th colspan="4"><p class="float-right">TOTAL IMPUESTO (<?php echo e($sale->tax); ?>%):</p></th>
                      <th><p class="float-right">$<?php echo e(number_format($subtotal * $sale->tax/100, 2, '.', ',')); ?></p></th>
                  </tr>
                  <tr>
                      <th colspan="4"><p class="float-right">TOTAL:</p></th>
                      <th><p class="float-right">$<?php echo e(number_format($sale->total, 2, '.', ',')); ?></p></th>
                  </tr>
  
              </tfoot>
                <tbody>
                  <?php $__currentLoopData = $saleDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $saleDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($saleDetail->product->name); ?></td>
                      <td>$<?php echo e($saleDetail->price); ?></td>
                      <td><?php echo e($saleDetail->quantity); ?></td>
                      <td><?php echo e($saleDetail->discount); ?>%</td>
                      <td>$<?php echo e(number_format(($saleDetail->quantity*$saleDetail->price)-($saleDetail->quantity*$saleDetail->price*$saleDetail->discount/100), 2, '.', ',')); ?></td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
          <div class="card-footer">
            <a href="<?php echo e(route('sales.index')); ?>" class="btn btn-primary float-right">Regresar</a>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->startSection('scripts'); ?>
  <?php echo e(Html::script("js/data-table.js")); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\puntodeventa\resources\views/admin/sale/show.blade.php ENDPATH**/ ?>